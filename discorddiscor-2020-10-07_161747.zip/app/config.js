exports.Prefix = '!';//your prefix for bot
exports.Token = 'NzYyNzM3MDEyMjg4NTIwMjcy.X3tgMg.vWcmSplDlUzy2uwx3MAhDDpgePE';//your token 
exports.Color = `COLOR OF ALL EMBEDES`;//color   of embed
